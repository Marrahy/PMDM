/**
 * Programa que muestra una serie de botones con los que puedes guardar el número de veces que pasa una
 * persona, una bicicleta, un patinete o un coche y muestra el porcentaje total de cada propiedad
 *
 * @author Sergi Marrahy Arenas
 * @version 3.1
 */

package com.sergimarrahy.sergistatistics

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import com.sergimarrahy.sergistatistics.ui.theme.SergiStatisticsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SergiStatisticsTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    statisticsSergi()
                }
            }
        }
    }
}

/**
 * Función que calcula el porcentaje de cada contador
 *
 * @param total La suma total de los contadores
 * @param counter Contador
 * @return el procentaje del contador
 */
@Composable
fun getPercentage(total: Int, counter: Int) :Int {
    return if (total != 0 && counter != 0) counter * 100 / total else 0
}

/**
 * Muestra un contador de personas, patinetes, bicicletas y coches con su procentaje correspondiente.
 */
@Composable
fun statisticsSergi() {
    val tittleFontSize = 24.sp
    val bodyFontSize = 18.sp
    var personCounter by rememberSaveable { mutableStateOf(0) }
    var scooterCounter by rememberSaveable { mutableStateOf(0) }
    var bicycleCounter by rememberSaveable { mutableStateOf(0) }
    var carCounter by rememberSaveable { mutableStateOf(0) }
    var totalCounter by rememberSaveable { mutableStateOf(0) }
    //Columna principal
    Column (
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text (
            text = "Estadísticas Sergi",
            fontSize = tittleFontSize,
        )
        Text (
            text = "Total: $totalCounter",
            fontSize = bodyFontSize
        )
        Button(onClick = {
            totalCounter = 0
            personCounter = 0
            scooterCounter = 0
            bicycleCounter = 0
            carCounter = 0
        },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF69F0AE),
                contentColor = Color.White
            )
        ) {
            Text(
                text = "Reiniciar todos"
            )
        }
        Row (
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Column (
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Personas",
                    fontSize = bodyFontSize
                )
                Button(onClick = {
                    personCounter++
                    totalCounter++
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF9E80),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "+1")
                }
                Button(onClick = {
                    if (personCounter > 0) {
                        personCounter--
                        totalCounter--
                    }
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB388FF),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "-1")
                }
                Button(onClick = {
                    totalCounter -= personCounter
                    personCounter = 0
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF8C9EFF),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "Reset")
                }
                Column (
                ) {
                    Text(
                        text = "$personCounter",
                        fontSize = tittleFontSize,
                    )
                }
            }

            Column (
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Patinetes",
                    fontSize = bodyFontSize
                )
                Button(onClick = {
                    scooterCounter++
                    totalCounter++
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF9E80),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "+1")
                }
                Button(onClick = {
                    if (scooterCounter > 0) {
                        scooterCounter--
                        totalCounter--
                    }
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB388FF),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "-1")
                }
                Button(onClick = {
                    totalCounter -= scooterCounter
                    scooterCounter = 0
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF8C9EFF),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "Reset")
                }
                Column (
                ){
                    Text(
                        text = "$scooterCounter",
                        fontSize = tittleFontSize,
                    )
                }
            }

            Column (
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Bicicletas",
                    fontSize = bodyFontSize
                )
                Button(onClick = {
                    bicycleCounter++
                    totalCounter++
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF9E80),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "+1")
                }
                Button(onClick = {
                    if (bicycleCounter > 0) {
                        bicycleCounter--
                        totalCounter--
                    }
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB388FF),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "-1")
                }
                Button(onClick = {
                    totalCounter -= bicycleCounter
                    bicycleCounter = 0
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF8C9EFF),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "Reset")
                }
                Column (
                ){
                    Text(
                        text = "$bicycleCounter",
                        fontSize = tittleFontSize,
                    )
                }
            }

            Column (
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Coches",
                    fontSize = bodyFontSize
                )
                Button(onClick = {
                    carCounter++
                    totalCounter++
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFF9E80),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "+1")
                }
                Button(onClick = {
                    if (carCounter > 0) {
                        carCounter--
                        totalCounter--
                    }
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB388FF),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "-1")
                }
                Button(onClick = {
                    totalCounter -= carCounter
                    carCounter = 0
                },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF8C9EFF),
                        contentColor = Color.White
                    )
                ) {
                    Text(text = "Reset")
                }
                Column (
                ) {
                    Text(
                        text = "$carCounter",
                        fontSize = tittleFontSize,
                    )
                }
            }
        }
        Column {
            Text (
                text = "Estadísticas",
                fontSize = bodyFontSize,
            )
            Text(
                text = """Personas -> ${getPercentage(totalCounter, personCounter)}%
                    |Patinetes -> ${getPercentage(totalCounter, scooterCounter)}%
                    |Bicicletas -> ${getPercentage(totalCounter, bicycleCounter)}%
                    |Coches     -> ${getPercentage(totalCounter, carCounter)}%
                """.trimMargin()
            )
        }
    }
}